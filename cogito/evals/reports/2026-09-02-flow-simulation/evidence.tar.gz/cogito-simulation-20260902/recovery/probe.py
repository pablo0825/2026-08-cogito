import sys, json, hashlib, subprocess, os
from pathlib import Path
BASE=Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/cogito-simulation-20260902/recovery/replay')
BASE.mkdir(parents=True,exist_ok=True)
SOURCE=Path('/Users/pablo/Documents/project/2026-08-cogito/cogito')
sys.path.insert(0,str(SOURCE/'tests'))
from cogito_test_support import init_repo, git, minimal_package, isolated_git_environment
GATE=SOURCE/'scripts/cogito_gate.py'
logs=[]
def cli(repo,*args):
    result=subprocess.run([sys.executable,str(GATE),'--repo',str(repo),*args],text=True,capture_output=True)
    row={'repo':str(repo),'args':args,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    logs.append(row)
    (BASE/'logs.json').write_text(json.dumps(logs,indent=2))
    try: output=json.loads(result.stdout or result.stderr)
    except: output={'error':(result.stdout or result.stderr)[-500:]}
    print(repo.name,args[0],args[args.index('--event')+1] if '--event' in args else '',result.returncode,output.get('data',{}).get('state'),str(output.get('error',''))[:150])
    return result,output

def setup(name):
    repo=BASE/name;repo.mkdir();init_repo(repo)
    (repo/'.gitignore').write_text('.cogito/\ndocs/cogito/packages/\n')
    (repo/'docs').mkdir();(repo/'docs/spec.md').write_text('規格\n');(repo/'docs/plan.md').write_text('計畫\n')
    git(repo,'add','.');git(repo,'commit','-qm','simulation baseline')
    run='DEV-'+name
    cli(repo,'init','--run-id',run,'--kind','feature')
    return repo,run

def event(repo,run,event,payload,action):
    return cli(repo,'transition','--run-id',run,'--event',event,'--payload-json',json.dumps(payload),'--action-id',action)
def block_resume(repo,run):
    cli(repo,'next','--run-id',run)
    event(repo,run,'block',{'reason':'simulation temporary unresolved decision'},'block-1')
    event(repo,run,'block',{'reason':'simulation additional evidence needed'},'block-2')
    cli(repo,'next','--run-id',run)
    cli(repo,'resume','--run-id',run,'--action-id','resume-1')
    cli(repo,'resume','--run-id',run,'--action-id','resume-1')
    cli(repo,'next','--run-id',run)
with isolated_git_environment():
    for target in ('preparing','shared','package'):
        repo,run=setup(target)
        if target!='preparing':
            event(repo,run,'shared-understanding-ready',{'shared_understanding_hash':'a'*64},'shared-ready')
        if target=='package':
            event(repo,run,'shared-understanding-confirmed',{'confirmed':True},'shared-confirm')
            event(repo,run,'boundary-complete',{'decision':'single-slice','evidence':['simulation bounded change']},'boundary')
            package=minimal_package();package['run_id']=run;package['baseline_commit']=git(repo,'rev-parse','HEAD')
            package['boundary']={'decision':'single-slice','evidence':['simulation bounded change']}
            for key in ('spec','plan'):
                package['slices'][0][key]['hash']=hashlib.sha256((repo/package['slices'][0][key]['path']).read_bytes()).hexdigest()
            package_path=BASE/'package-draft.json';package_path.write_text(json.dumps(package))
            cli(repo,'prepare-package','--run-id',run,'--package',str(package_path),'--action-id','prepare')
        block_resume(repo,run)
    repo,run=setup('payload')
    for size in (50,240,260,500,2000,10000):
        event(repo,run,'block',{'reason':'x'*size},'payload-'+str(size))
    payload_file=BASE/'long-payload.json';payload_file.write_text(json.dumps({'reason':'x'*10000}))
    cli(repo,'transition','--run-id',run,'--event','block','--payload-json',str(payload_file),'--action-id','file-payload')
print('Wrote',BASE/'logs.json')
