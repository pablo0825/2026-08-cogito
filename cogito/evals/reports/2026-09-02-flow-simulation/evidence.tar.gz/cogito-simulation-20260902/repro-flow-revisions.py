import sys,json,subprocess,tempfile
from pathlib import Path
sys.path.insert(0,'/Users/pablo/Documents/project/2026-08-cogito/cogito/tests')
from cogito_test_support import isolated_git_environment,init_repo,git,minimal_package
GATE='/Users/pablo/Documents/project/2026-08-cogito/cogito/scripts/cogito_gate.py'
log=[]
def cmd(root,*args):
 p=subprocess.run([sys.executable,GATE,'--repo',str(root),*args],capture_output=True,text=True)
 item={'args':args,'code':p.returncode,'output':json.loads(p.stdout or p.stderr)}
 log.append(item)
 return item
with isolated_git_environment(),tempfile.TemporaryDirectory(prefix='cogito-flow-audit-') as tmp:
 root=Path(tmp);init_repo(root);git(root,'commit','--allow-empty','-qm','baseline')
 run='DEV-flow-revisions'
 cmd(root,'init','--run-id',run,'--kind','feature')
 def transition(event,payload,action):
  return cmd(root,'transition','--run-id',run,'--event',event,'--payload-json',json.dumps(payload),'--action-id',action)
 transition('shared-understanding-ready',{'shared_understanding_hash':'a'*64},'shared-v1')
 transition('shared-understanding-ready',{'shared_understanding_hash':'b'*64},'shared-v2')
 transition('block',{'reason':'user revised summary'},'block')
 cmd(root,'resume','--run-id',run,'--action-id','resume')
 transition('shared-understanding-ready',{'shared_understanding_hash':'b'*64},'shared-v2-after-resume')
 transition('shared-understanding-confirmed',{'confirmed':True},'confirm')
 package=minimal_package();package['run_id']=run
 transition('boundary-complete',package['boundary'],'boundary')
 draft=root/'draft.json';draft.write_text(json.dumps(package))
 cmd(root,'prepare-package','--run-id',run,'--package',str(draft),'--action-id','prepare-v1')
 package['stop_conditions'].append('user-requested-extra-stop-condition');draft.write_text(json.dumps(package))
 cmd(root,'prepare-package','--run-id',run,'--package',str(draft),'--action-id','prepare-v2')
 cmd(root,'approve','--run-id',run,'--package',str(draft),'--action-id','approve-v2')
 cmd(root,'next','--run-id',run)
Path('/tmp/cogito-simulation-20260902/flow-revisions-log.json').write_text(json.dumps(log,indent=2))
for x in log:
 data=x['output'];print(x['args'][0], x['args'][-1],x['code'],data.get('error') or data.get('data',{}).get('state'))
