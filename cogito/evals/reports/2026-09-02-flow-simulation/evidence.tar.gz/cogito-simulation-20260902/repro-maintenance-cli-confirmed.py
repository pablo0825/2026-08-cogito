import sys,json,tempfile
from pathlib import Path
sys.path.insert(0,'/Users/pablo/Documents/project/2026-08-cogito/cogito/tests')
from cogito_test_support import isolated_git_environment,init_repo,git,package
import cogito_runtime as rt
from cli_adapter_maintenance import CliStore
from contextlib import contextmanager
@contextmanager
def retained_repo(**kwargs):
 p=Path("/tmp/cogito-simulation-20260902/maintenance-cli-confirmed/repo");p.mkdir(parents=True)
 yield str(p)
logs=[]
def note(label,value): logs.append({'step':label,'value':value});print(label,value)
with isolated_git_environment(),retained_repo(prefix='cogito-maint-correction-') as tmp:
 repo=Path(tmp);init_repo(repo)
 (repo/'.gitignore').write_text('.cogito/\ndocs/cogito/packages/\n');(repo/'note.txt').write_text('before\n')
 git(repo,'add','.');git(repo,'commit','-qm','baseline');base=git(repo,'rev-parse','HEAD');run='DEV-maint-correction'
 pkg=package('maintenance');pkg.update(run_id=run,baseline_commit=base,delivery_branch='main',approved_paths=['note.txt'],execution_dag={'tasks':[{'id':'T-1','paths':['note.txt']}],'edges':[]},checks=[{'id':'C-1','required':True,'argv':[sys.executable,'-I','-c',"from pathlib import Path; assert Path('note.txt').read_text() == 'after\\n'"]}])
 store=CliStore(repo,run);store.create('maintenance');store.prepare_package(pkg);store.approve_package(pkg);store.start_gate()
 store.update_task('T-1','leased','worker-1');store.update_task('T-1','running','worker-1');(repo/'note.txt').write_text('wrong\n')
 store.submit_agent_result({'schema_version':'3.0','run_id':run,'task_id':'T-1','agent_id':'worker-1','role':'implementer','status':'complete','base_commit':base,'head_commit':base,'changed_paths':['note.txt'],'evidence':[],'risks':[],'requested_transition':'verifying'})
 store.update_task('T-1','complete','worker-1');store.transition('implementation-complete',{})
 def check(action):
  before=set((store.run_dir/'evidence').glob('*.json'));store.run_controlled_check('C-1',repo,action)
  return json.loads(next(iter(set((store.run_dir/'evidence').glob('*.json'))-before)).read_text())
 failed=check('failed');note('initial-check-passed',failed['passed'])
 store.add_amendment({'id':'TA-1','reason':'fix internal typo','path_fixes':['note.txt']});store.enter_correction();(repo/'note.txt').write_text('after\n')
 try: store.complete_correction('TA-1',base)
 except rt.CogitoError as e: note('correction-without-commit-rejected',str(e))
 git(repo,'add','note.txt');git(repo,'commit','-qm','fix typo\n\nCogito-Amendment: TA-1');fix=git(repo,'rev-parse','HEAD')
 store.complete_correction('TA-1',fix);note('correction-with-commit-state',store.load()['state'])
 verified=check('fixed');store.complete_verification([verified]);store.transition('review-approved',{'review_exemption':True});store.complete_integration(fix)
 post=check('post');store.decide_post_verification([post]);note('state-before-final-commit',store.load()['state'])
 graphp=repo/'docs/cogito/project-graph.json';graph=json.loads(graphp.read_text());graph['active_run_id']=None;graphp.write_text(json.dumps(graph))
 resultp=repo/f'docs/cogito/results/{run}.json';resultp.parent.mkdir(parents=True);resultp.write_text(json.dumps({'schema_version':'3.0','run_id':run,'status':'accepted','package_hash':rt.package_hash(store.approved_package()),'effective_contract_hash':store.load()['effective_contract_hash'],'integration_commits':[fix],'slice_dispositions':{},'checks':[{'id':'C-1','status':'passed','evidence':post['evidence_path']}],'reviews':[],'amendments':[{'id':'TA-1','commit_id':fix}],'human_gate':{'required':False,'outcome':'not-required'},'remaining_risks':[]}))
 git(repo,'add','docs/cogito/project-graph.json',str(resultp));git(repo,'commit','-qm','finalize');final=git(repo,'rev-parse','HEAD')
 note('new-commit-count',git(repo,'rev-list','--count',f'{base}..{final}'))
 try: store.finalize(str(resultp.relative_to(repo)),'docs/cogito/project-graph.json',final)
 except rt.CogitoError as e: note('finalize-rejected',str(e))
 note('final-state',store.load()['state'])
Path('/tmp/cogito-simulation-20260902/maintenance-cli-confirmed/maintenance-correction-log.json').write_text(json.dumps(logs,indent=2))
