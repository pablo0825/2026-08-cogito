"""Probe a valid Maintenance delivery with staged and unstaged content."""
import json, sys
from pathlib import Path
sys.path.insert(0,'/Users/pablo/Documents/project/2026-08-cogito/cogito/tests')
from cogito_test_support import isolated_git_environment, init_repo, git, package
from test_maintenance_corrections import MaintenanceCli

OUT=Path(__file__).resolve().parent/'staged-maintenance'
OUT.mkdir(exist_ok=True)
records=[]
class LoggedCli(MaintenanceCli):
    def call(self, command, *options):
        try:
            value=super().call(command,*options)
            records.append({'command':command,'options':list(map(str,options)),'ok':True,'state':value.get('state')})
            return value
        except Exception as exc:
            records.append({'command':command,'options':list(map(str,options)),'ok':False,'error':str(exc)})
            raise

summaries=[]
with isolated_git_environment():
 for mode in ('unstaged','staged','mixed'):
    repo=OUT/mode;repo.mkdir()
    init_repo(repo)
    (repo/'.gitignore').write_text('.cogito/\ndocs/cogito/packages/\n')
    (repo/'note.txt').write_text('before\n')
    git(repo,'add','.')
    git(repo,'commit','-qm','baseline')
    base=git(repo,'rev-parse','HEAD')
    draft=package('maintenance')
    draft.update(run_id='MNT-staged-'+mode,baseline_commit=base,approved_paths=['note.txt'],execution_dag={'tasks':[{'id':'T-1','paths':['note.txt']}],'edges':[]})
    store=LoggedCli(repo,draft['run_id'])
    store.create('maintenance');store.prepare_package(draft);store.approve_package(draft);store.start_gate()
    store.update_task('T-1','leased','worker');store.update_task('T-1','running','worker')
    (repo/'note.txt').write_text('after\n')
    if mode in ('staged','mixed'):git(repo,'add','note.txt')
    if mode=='mixed':(repo/'note.txt').write_text('after again\n')
    data={'schema_version':'3.0','run_id':store.run_id,'task_id':'T-1','agent_id':'worker','role':'implementer','status':'complete','base_commit':base,'head_commit':base,'changed_paths':['note.txt'],'evidence':[],'risks':[],'requested_transition':'verifying'}
    before=store.events_path.read_bytes()
    item={'case':mode,'git_status':git(repo,'status','--porcelain'),'head':base}
    try:
        store.submit_agent_result(data);item['accepted']=True
    except Exception as exc:
        item.update(accepted=False,error=str(exc),events_unchanged=before==store.events_path.read_bytes())
    item['state']=store.load()['state'];summaries.append(item)
(OUT/'summary.json').write_text(json.dumps(summaries,indent=2))
(OUT/'cli-log.json').write_text(json.dumps(records,indent=2))
print(json.dumps(summaries,indent=2))
