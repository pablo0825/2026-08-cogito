"""Check whether staged out-of-scope content is caught before acceptance."""
import json,sys
from pathlib import Path
sys.path.insert(0,'/Users/pablo/Documents/project/2026-08-cogito/cogito/tests')
from cogito_test_support import isolated_git_environment,init_repo,git,package
from test_maintenance_corrections import MaintenanceCli
OUT=Path(__file__).resolve().parent/'staged-scope';OUT.mkdir()
repo=OUT/'repo';repo.mkdir()
records=[]
class LoggedCli(MaintenanceCli):
 def call(self, command,*options):
  try:
   value=super().call(command,*options)
   records.append({'command':command,'options':list(map(str,options)),'result':value})
   return value
  finally:
   (OUT/'cli-log.json').write_text(json.dumps(records,indent=2))
with isolated_git_environment():
 init_repo(repo)
 (repo/'.gitignore').write_text('.cogito/\ndocs/cogito/packages/\n')
 (repo/'note.txt').write_text('before\n');(repo/'unrelated.txt').write_text('preserve\n')
 git(repo,'add','.');git(repo,'commit','-qm','baseline');base=git(repo,'rev-parse','HEAD')
 draft=package('maintenance')
 draft.update(run_id='MNT-staged-scope',baseline_commit=base,approved_paths=['note.txt'],execution_dag={'tasks':[{'id':'T-1','paths':['note.txt']}],'edges':[]},checks=[{'id':'C-1','required':True,'argv':[sys.executable,'-I','-c',"from pathlib import Path; assert Path('note.txt').read_text() == 'after\\n'"]}])
 store=LoggedCli(repo,draft['run_id']);store.create('maintenance');store.prepare_package(draft);store.approve_package(draft);store.start_gate()
 store.update_task('T-1','leased','worker');store.update_task('T-1','running','worker')
 (repo/'note.txt').write_text('after\n');(repo/'unrelated.txt').write_text('unexpected staged modification\n');git(repo,'add','unrelated.txt')
 store.submit_agent_result({'schema_version':'3.0','run_id':store.run_id,'task_id':'T-1','agent_id':'worker','role':'implementer','status':'complete','base_commit':base,'head_commit':base,'changed_paths':['note.txt'],'evidence':[],'risks':[],'requested_transition':'verifying'})
 store.update_task('T-1','complete','worker');store.transition('implementation-complete',{})
 def check(label):
  before=set((store.run_dir/'evidence').glob('*.json'));store.run_controlled_check('C-1',repo,label)
  path,=set((store.run_dir/'evidence').glob('*.json'))-before
  value=json.loads(path.read_text());assert value['passed'];return value
 store.complete_verification([check('pre')]);store.transition('review-approved',{'review_exemption':True});store.complete_integration(base)
 post=check('post');store.decide_post_verification([post])
 graph_path=repo/'docs/cogito/project-graph.json';graph=json.loads(graph_path.read_text());graph['active_run_id']=None;graph_path.write_text(json.dumps(graph))
 result_rel=f'docs/cogito/results/{store.run_id}.json';result_path=repo/result_rel;result_path.parent.mkdir(parents=True)
 result_path.write_text(json.dumps({'schema_version':'3.0','run_id':store.run_id,'status':'accepted','package_hash':store.load()['package_hash'],'effective_contract_hash':store.load()['effective_contract_hash'],'integration_commits':[base],'slice_dispositions':{},'checks':[{'id':'C-1','status':'passed','evidence':post['evidence_path']}],'reviews':[],'amendments':[],'human_gate':{'required':False,'outcome':'not-required'},'remaining_risks':[]}))
 git(repo,'add','note.txt',result_rel,'docs/cogito/project-graph.json');git(repo,'commit','-qm','finalize')
 final=git(repo,'rev-parse','HEAD');state=store.finalize(result_rel,'docs/cogito/project-graph.json',final)
 summary={'state':state['state'],'approved_paths':draft['approved_paths'],'declared_changed_paths':['note.txt'],'actual_final_diff':git(repo,'diff','--name-only',base,final).splitlines(),'unrelated_content':git(repo,'show',f'{final}:unrelated.txt'),'final_commit':final}
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
