from pathlib import Path
import os, sys, json, subprocess, hashlib, copy, concurrent.futures, traceback
ROOT=Path('/tmp/cogito-resimulation-20260902/preapproval')
SRC=Path('/Users/pablo/Documents/project/2026-08-cogito/cogito')
sys.path[:0]=[str(SRC/'tests'),str(SRC/'scripts')]
from cogito_test_support import package
from cogito_contracts import package_hash
ENV={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
ENV.update(GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_SYSTEM='/dev/null',GIT_CONFIG_NOSYSTEM='1',GIT_TERMINAL_PROMPT='0',PYTHONDONTWRITEBYTECODE='1')
LOG=ROOT/'commands.jsonl'
RESULTS=[]
def run(argv,cwd=None):
 p=subprocess.run(list(map(str,argv)),cwd=cwd,env=ENV,text=True,capture_output=True)
 with LOG.open('a') as f:f.write(json.dumps({'argv':list(map(str,argv)),'cwd':str(cwd),'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr},ensure_ascii=False)+'\n')
 return p
def cli(repo,*args,ok=True):
 p=run([sys.executable,SRC/'scripts/cogito_gate.py','--repo',repo,*args])
 if ok:assert p.returncode==0,p.stderr
 else:assert p.returncode!=0,p.stdout
 return p

def fixture(label,kind='feature'):
 repo=ROOT/label;repo.mkdir()
 for args in [('init','-q','--template=','-b','main'),('config','user.name','Simulation'),('config','user.email','sim@example.invalid'),('config','commit.gpgsign','false'),('config','core.hooksPath','/dev/null')]:assert run(['git',*args],repo).returncode==0
 (repo/'.gitignore').write_text('.cogito/\n');(repo/'docs').mkdir()
 for n in ('spec','plan'):(repo/f'docs/{n}.md').write_text(n+'\n')
 assert run(['git','add','.'],repo).returncode==0
 assert run(['git','commit','-qm','baseline'],repo).returncode==0
 pkg=package(kind);pkg['run_id']='DEV-'+label;pkg['baseline_commit']=run(['git','rev-parse','HEAD'],repo).stdout.strip()
 for item in pkg['slices']:
  for name in ('spec','plan'):item[name]['hash']=hashlib.sha256((repo/item[name]['path']).read_bytes()).hexdigest()
 cli(repo,'init','--run-id',pkg['run_id'],'--kind',kind)
 return repo,pkg

def transition(repo,rid,event,payload,aid,ok=True):return cli(repo,'transition','--run-id',rid,'--event',event,'--payload-json',json.dumps(payload,ensure_ascii=False),'--action-id',aid,ok=ok)
def events(repo,rid):return repo/'.cogito/runs'/rid/'events.jsonl'
def record(label,body):
 try:body();RESULTS.append({'case':label,'passed':True})
 except Exception as e:RESULTS.append({'case':label,'passed':False,'error':str(e),'traceback':traceback.format_exc()})
 (ROOT/'results.json').write_text(json.dumps(RESULTS,ensure_ascii=False,indent=2))

def revisions():
 repo,pkg=fixture('shared');rid=pkg['run_id'];ev=events(repo,rid)
 transition(repo,rid,'shared-understanding-ready',{'shared_understanding_hash':'a'*64},'ready-a')
 transition(repo,rid,'block',{'reason':'摘要需修改'},'block')
 r=cli(repo,'resume','--run-id',rid,'--action-id','resume');assert json.loads(r.stdout)['data']['state']=='awaiting-shared-confirmation'
 transition(repo,rid,'shared-understanding-ready',{'shared_understanding_hash':'b'*64},'ready-b')
 before=ev.read_bytes()
 for tag,payload in [('missing',{'confirmed':True}),('stale',{'confirmed':True,'shared_understanding_hash':'a'*64})]:
  transition(repo,rid,'shared-understanding-confirmed',payload,'confirm-'+tag,ok=False);assert ev.read_bytes()==before
 transition(repo,rid,'shared-understanding-confirmed',{'confirmed':True,'shared_understanding_hash':'b'*64},'confirm-b')
 transition(repo,rid,'boundary-complete',pkg['boundary'],'boundary')
 pkg['shared_understanding']['hash']='a'*64;p=ROOT/'shared-old.json';p.write_text(json.dumps(pkg));cli(repo,'prepare-package','--run-id',rid,'--package',p,'--action-id','prepare-old',ok=False)
 pkg['shared_understanding']['hash']='b'*64;p=ROOT/'shared-new.json';p.write_text(json.dumps(pkg));cli(repo,'prepare-package','--run-id',rid,'--package',p,'--action-id','prepare-new')
record('Shared A→block/resume→B; missing/stale confirm rejected; latest package accepted',revisions)

def packages(kind):
 repo,pkg=fixture('pkg-'+kind,kind);rid=pkg['run_id'];ev=events(repo,rid)
 if kind=='feature':
  transition(repo,rid,'shared-understanding-ready',{'shared_understanding_hash':pkg['shared_understanding']['hash']},'ready')
  transition(repo,rid,'shared-understanding-confirmed',{'confirmed':True},'confirm')
  transition(repo,rid,'boundary-complete',pkg['boundary'],'boundary')
 p1=ROOT/(kind+'-v1.json');p2=ROOT/(kind+'-v2.json');p1.write_text(json.dumps(pkg))
 revised=copy.deepcopy(pkg);revised['stop_conditions'].append('新增停止條件');p2.write_text(json.dumps(revised))
 for p,aid in [(p1,'prepare1'),(p2,'prepare2')]:cli(repo,'prepare-package','--run-id',rid,'--package',p,'--action-id',aid)
 before=ev.read_bytes();cli(repo,'approve','--run-id',rid,'--package',p1,'--action-id','approve1',ok=False);assert before==ev.read_bytes()
 cli(repo,'approve','--run-id',rid,'--package',p2,'--action-id','approve2')
 canon=repo/'docs/cogito/packages'/f'{rid}.json';assert json.loads(canon.read_text())==revised
 before=ev.read_bytes();cli(repo,'prepare-package','--run-id',rid,'--package',p1,'--action-id','prepare3',ok=False);assert before==ev.read_bytes()
for kind in ['feature','maintenance','documentation']:record(kind+' package revision approval',lambda kind=kind:packages(kind))

def payloads():
 repo,pkg=fixture('payload');payload={'reason':'等待確認完整中文測試'*400,'details':['保留完整證據',True,42]};encoded=json.dumps(payload,ensure_ascii=False);assert len(encoded.encode())>10240
 path=ROOT/'payload-utf8.json';path.write_text(encoded)
 observed=[]
 for label,arg in [('inline',encoded),('file',str(path))]:
  rid='DEV-json-'+label;cli(repo,'init','--run-id',rid,'--kind','feature');cli(repo,'transition','--run-id',rid,'--event','block','--payload-json',arg,'--action-id','block');observed.append(json.loads(events(repo,rid).read_text().splitlines()[-1])['payload'])
 assert observed==[payload,payload]
 bad=ROOT/'invalid-utf8.json';bad.write_bytes(b'{"reason":"\xff"}')
 for label,arg in [('invalid-utf8',str(bad)),('long-invalid','x'*20000),('long-array',json.dumps(['中'*12000]))]:
  rid='DEV-json-'+label;cli(repo,'init','--run-id',rid,'--kind','feature');ev=events(repo,rid);before=ev.read_bytes();p=cli(repo,'transition','--run-id',rid,'--event','block','--payload-json',arg,'--action-id','block',ok=False);assert p.returncode==2;assert json.loads(p.stderr)['ok']==False;assert 'Traceback' not in p.stderr;assert before==ev.read_bytes()
record('>10KB Chinese JSON inline/file equivalence and invalid inputs structured rejection',payloads)

# Additional boundary: --package uses a separate parser from --payload-json.
def bad_package():
 repo,pkg=fixture('bad-package','maintenance');rid=pkg['run_id'];before=events(repo,rid).read_bytes();p=cli(repo,'prepare-package','--run-id',rid,'--package',ROOT/'invalid-utf8.json','--action-id','bad-utf8',ok=False)
 assert before==events(repo,rid).read_bytes()
 assert p.returncode==2 and 'Traceback' not in p.stderr,p.stderr
record('Invalid UTF8 package file structured rejection',bad_package)
print(json.dumps(RESULTS,ensure_ascii=False,indent=2))
