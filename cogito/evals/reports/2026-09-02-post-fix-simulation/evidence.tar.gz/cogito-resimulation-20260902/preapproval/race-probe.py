from pathlib import Path
src=Path('/tmp/cogito-resimulation-20260902/preapproval/probe.py').read_text().split('def revisions():')[0]
src=src.replace("ROOT=Path('/tmp/cogito-resimulation-20260902/preapproval')","ROOT=Path('/tmp/cogito-resimulation-20260902/preapproval/races')\nROOT.mkdir()")
exec(src)
import threading

def race(kind,i):
 repo,pkg=fixture(f'race-{kind}-{i}',kind);rid=pkg['run_id']
 if kind=='feature':
  transition(repo,rid,'shared-understanding-ready',{'shared_understanding_hash':pkg['shared_understanding']['hash']},'ready')
  transition(repo,rid,'shared-understanding-confirmed',{'confirmed':True},'confirm')
  transition(repo,rid,'boundary-complete',pkg['boundary'],'boundary')
 p1=ROOT/f'{rid}-v1.json';p1.write_text(json.dumps(pkg));p2=ROOT/f'{rid}-v2.json';v2=copy.deepcopy(pkg);v2['stop_conditions'].append('race revised');p2.write_text(json.dumps(v2))
 cli(repo,'prepare-package','--run-id',rid,'--package',p1,'--action-id','initial')
 barrier=threading.Barrier(2)
 def contender(command,path,aid):
  barrier.wait()
  return run([sys.executable,SRC/'scripts/cogito_gate.py','--repo',repo,command,'--run-id',rid,'--package',path,'--action-id',aid])
 with concurrent.futures.ThreadPoolExecutor(2) as pool:
  a=pool.submit(contender,'approve',p1,'approve-old');b=pool.submit(contender,'prepare-package',p2,'revise');rr=[a.result(),b.result()]
 status=json.loads(cli(repo,'status','--run-id',rid).stdout)['data'];canon=repo/'docs/cogito/packages'/f'{rid}.json';history=[json.loads(x) for x in events(repo,rid).read_text().splitlines()]
 if status['state']=='start-gate':
  assert canon.exists();assert package_hash(json.loads(canon.read_text()))==status['package_hash']==package_hash(pkg)
  assert sum(x['type']=='package-approved' for x in history)==1
 elif status['state']=='awaiting-package-approval':
  assert status['candidate_package_hash']==package_hash(v2);assert not canon.exists();assert not any(x['type']=='package-approved' for x in history)
  cli(repo,'approve','--run-id',rid,'--package',p2,'--action-id','approve-latest')
 else:raise AssertionError(status)
 assert all(p.returncode in (0,2) for p in rr),[p.stderr for p in rr]
 print(kind,i,'contender exits',[p.returncode for p in rr],'winner state',status['state'])
for kind in ['feature','maintenance','documentation']:
 for i in range(3):record(f'{kind} CLI approval vs candidate revision race {i}',lambda k=kind,n=i:race(k,n))
print(json.dumps(RESULTS,indent=2))
