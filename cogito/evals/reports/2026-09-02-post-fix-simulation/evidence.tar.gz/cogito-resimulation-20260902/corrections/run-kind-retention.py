import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/Users/pablo/Documents/project/2026-08-cogito/cogito/tests')
from cogito_test_support import isolated_git_environment,init_repo,git,package
from test_maintenance_corrections import MaintenanceCli
from cogito_common import CogitoError
OUT=Path('/tmp/cogito-resimulation-20260902/corrections');logs=[]
class CLI(MaintenanceCli):
 def call(self,command,*options):
  try:
   value=super().call(command,*options);logs.append({'kind':self.kind,'command':command,'options':list(map(str,options)),'ok':True,'result':value});return value
  except Exception as e:
   logs.append({'kind':self.kind,'command':command,'options':list(map(str,options)),'ok':False,'error':str(e)});raise
results=[]
with isolated_git_environment():
 for kind in ['feature','documentation']:
  repo=OUT/(kind+'-repo-v2');repo.mkdir();init_repo(repo);(repo/'.gitignore').write_text('.cogito/\ndocs/cogito/packages/\n');(repo/'src').mkdir();(repo/'src/note.txt').write_text('before\n');(repo/'docs').mkdir()
  for name in ['spec','plan']:(repo/f'docs/{name}.md').write_text('既有規格與計畫\n')
  git(repo,'add','.');git(repo,'commit','-qm','baseline');base=git(repo,'rev-parse','HEAD');run='DEV-'+kind+'-retention';p=package(kind);p.update(run_id=run,baseline_commit=base,approved_paths=['src/note.txt'],execution_dag={'tasks':[{'id':'T-1','paths':['src/note.txt'],**({'slice_id':'FS-1'} if kind=='feature' else {})}],'edges':[]})
  if kind=='feature':
   p['slices'][0]['worker']['allowed_paths']=['src/note.txt']
   for name in ['spec','plan']:p['slices'][0][name]['hash']=hashlib.sha256((repo/f'docs/{name}.md').read_bytes()).hexdigest()
  c=CLI(repo,run);c.kind=kind;c.create(kind)
  if kind=='feature':
   c.transition('shared-understanding-ready',{'shared_understanding_hash':p['shared_understanding']['hash']});c.transition('shared-understanding-confirmed',{'confirmed':True});c.transition('boundary-complete',p['boundary'])
  c.prepare_package(p);c.approve_package(p);c.start_gate();work=repo
  if kind=='feature':work=repo/'.cogito/worktrees/FS-1';git(repo,'worktree','add','-q','-b','codex/fs-1',str(work),base)
  def result(task,taskbase,head):
   c.submit_agent_result({'schema_version':'3.0','run_id':run,'task_id':task,'agent_id':'worker','role':'implementer','status':'complete','base_commit':taskbase,'head_commit':head,'changed_paths':['src/note.txt'],'evidence':[],'risks':[],'requested_transition':'verifying'})
  c.update_task('T-1','leased','worker');c.update_task('T-1','running','worker');(work/'src/note.txt').write_text('initial\n');git(work,'add','src/note.txt');git(work,'commit','-qm','initial implementation');head1=git(work,'rev-parse','HEAD');result('T-1',base,head1);c.update_task('T-1','complete','worker');c.transition('implementation-complete',{})
  c.add_amendment({'id':'TA-1','reason':'修正既有實作','added_tasks':[{'id':'T-2','paths':['src/note.txt'],'slice_id':'FS-1' if kind=='feature' else 'mini-package'}]});c.enter_correction();c.update_task('T-2','leased','worker');c.update_task('T-2','running','worker');(work/'src/note.txt').write_text('corrected\n');git(work,'add','src/note.txt');git(work,'commit','-qm','missing trailer');bad=git(work,'rev-parse','HEAD');result('T-2',head1,bad);c.update_task('T-2','complete','worker');before=c.events_path.read_bytes()
  try:c.complete_correction('TA-1',bad);raise AssertionError('missing trailer accepted')
  except CogitoError as e:assert 'missing the Cogito-Amendment trailer' in str(e)
  assert c.events_path.read_bytes()==before
  git(work,'commit','--allow-empty','-qm','補記修正依據\n\nCogito-Amendment: TA-1');good=git(work,'rev-parse','HEAD');result('T-2',head1,good);state=c.complete_correction('TA-1',good);assert state['state']=='verifying';event=json.loads(c.events_path.read_text().splitlines()[-1]);assert 'completion_mode' not in event['payload'] and 'content_tree' not in event['payload'];assert event['payload']['commit_id']==good
  results.append({'kind':kind,'missing_trailer_rejected':True,'events_unchanged_on_rejection':True,'commit_completion_accepted':True,'completion_payload':event['payload']})
(OUT/'kind-retention-cli-log.json').write_text(json.dumps(logs,indent=2));(OUT/'kind-retention-summary.json').write_text(json.dumps(results,indent=2));print('PASS Feature/documentation retain real commit/trailer completion')
