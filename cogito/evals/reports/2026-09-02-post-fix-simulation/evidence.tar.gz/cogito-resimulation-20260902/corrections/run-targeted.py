import sys,unittest,json,copy
from pathlib import Path
sys.path.insert(0,'/Users/pablo/Documents/project/2026-08-cogito/cogito/tests')
from test_maintenance_corrections import MaintenanceCorrectionTests
from test_maintenance_amendment_records import snapshot_context
from test_finalization_rules import context
from cogito_finalization_rules import validate_finalization_records
from cogito_common import CogitoError
from cogito_contracts import package_hash
def fix_kind(value, kind):
 value.package["kind"] = kind
 value.result["package_hash"] = package_hash(value.package)
 if kind == "documentation": value.result["reviews"] = [{"reviewer":"reviewer-1"}]
 return value
class CliNegativeCases(MaintenanceCorrectionTests):
 def test_cli_staged_scope(self):self.run_corrections(cli=True,reject='staged-scope')
 def test_cli_untracked_scope(self):self.run_corrections(cli=True,reject='untracked-scope')
 def test_cli_early_commit(self):self.run_corrections(cli=True,reject='early-commit')
 def test_cli_missing_trailer(self):self.run_corrections(cli=True,reject='missing-trailer')
 def test_cli_missing_one_trailer(self):self.run_corrections(cli=True,post_correction=True,reject='missing-first-trailer')
 def test_cli_merge_final(self):self.run_corrections(cli=True,reject='merge-final')
class KindRetention(unittest.TestCase):
 def test_feature_documentation_cannot_use_maintenance_snapshots(self):
  for kind in ['feature','documentation']:
   with self.subTest(kind=kind):
    value=fix_kind(snapshot_context(kind),kind)
    with self.assertRaisesRegex(CogitoError,'Maintenance correction history'):validate_finalization_records(value)
 def test_feature_documentation_keep_commit_amendment_records(self):
  for kind in ['feature','documentation']:
   with self.subTest(kind=kind):
    value=fix_kind(context(kind),kind);before=copy.deepcopy(value);validate_finalization_records(value);self.assertEqual(value,before)
suite=unittest.TestSuite(CliNegativeCases(name) for name in ['test_cli_staged_scope','test_cli_untracked_scope','test_cli_early_commit','test_cli_missing_trailer','test_cli_missing_one_trailer','test_cli_merge_final']);suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(KindRetention))
with Path('/tmp/cogito-resimulation-20260902/corrections/targeted-tests.log').open('w') as f:r=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
print('tests',r.testsRun,'errors',len(r.errors),'failures',len(r.failures));raise SystemExit(not r.wasSuccessful())
