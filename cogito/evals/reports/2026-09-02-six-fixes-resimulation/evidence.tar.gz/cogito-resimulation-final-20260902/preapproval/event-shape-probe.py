from pathlib import Path
s=Path('/tmp/cogito-resimulation-final-20260902/preapproval/probe.py').read_text().split('def revisions():')[0]
s=s.replace("ROOT=Path('/tmp/cogito-resimulation-final-20260902/preapproval')","ROOT=Path('/tmp/cogito-resimulation-final-20260902/preapproval/event-shape')\nROOT.mkdir()")
exec(s)
repo,pkg=fixture('repo','maintenance');rid=pkg['run_id'];ev=events(repo,rid);before=ev.read_bytes();cache=ev.with_name('state.json');cached=cache.read_bytes()
records=[]
for label,content in [('array',b'[]'),('null',b'null')]:
 damaged=before+content+b'\n';ev.write_bytes(damaged)
 p=cli(repo,'status','--run-id',rid,ok=False)
 record={'case':label,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'events_unchanged':ev.read_bytes()==damaged,'cache_unchanged':cache.read_bytes()==cached,'events_before_sha256':hashlib.sha256(damaged).hexdigest(),'events_after_sha256':hashlib.sha256(ev.read_bytes()).hexdigest()}
 records.append(record);(ROOT/(label+'-damaged-events.jsonl')).write_bytes(damaged)
(ROOT/'results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print(json.dumps(records,ensure_ascii=False,indent=2))
