from pathlib import Path
import os, sys, json, subprocess, hashlib, copy, concurrent.futures, traceback
ROOT=Path('/tmp/cogito-resimulation-final-20260902/preapproval/encoding-recovery')
ROOT.mkdir()
SRC=Path('/Users/pablo/Documents/project/2026-08-cogito/cogito')
sys.path[:0]=[str(SRC/'tests'),str(SRC/'scripts')]
from cogito_test_support import package
from cogito_contracts import package_hash
ENV={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
ENV.update(GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_SYSTEM='/dev/null',GIT_CONFIG_NOSYSTEM='1',GIT_TERMINAL_PROMPT='0',PYTHONDONTWRITEBYTECODE='1')
LOG=ROOT/'commands.jsonl'
RESULTS=[]
def run(argv,cwd=None):
 p=subprocess.run(list(map(str,argv)),cwd=cwd,env=ENV,text=True,capture_output=True)
 with LOG.open('a') as f:f.write(json.dumps({'argv':list(map(str,argv)),'cwd':str(cwd),'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr},ensure_ascii=False)+'\n')
 return p
def cli(repo,*args,ok=True):
 p=run([sys.executable,SRC/'scripts/cogito_gate.py','--repo',repo,*args])
 if ok:assert p.returncode==0,p.stderr
 else:assert p.returncode!=0,p.stdout
 return p

def fixture(label,kind='feature'):
 repo=ROOT/label;repo.mkdir()
 for args in [('init','-q','--template=','-b','main'),('config','user.name','Simulation'),('config','user.email','sim@example.invalid'),('config','commit.gpgsign','false'),('config','core.hooksPath','/dev/null')]:assert run(['git',*args],repo).returncode==0
 (repo/'.gitignore').write_text('.cogito/\n');(repo/'docs').mkdir()
 for n in ('spec','plan'):(repo/f'docs/{n}.md').write_text(n+'\n')
 assert run(['git','add','.'],repo).returncode==0
 assert run(['git','commit','-qm','baseline'],repo).returncode==0
 pkg=package(kind);pkg['run_id']='DEV-'+label;pkg['baseline_commit']=run(['git','rev-parse','HEAD'],repo).stdout.strip()
 for item in pkg['slices']:
  for name in ('spec','plan'):item[name]['hash']=hashlib.sha256((repo/item[name]['path']).read_bytes()).hexdigest()
 cli(repo,'init','--run-id',pkg['run_id'],'--kind',kind)
 return repo,pkg

def transition(repo,rid,event,payload,aid,ok=True):return cli(repo,'transition','--run-id',rid,'--event',event,'--payload-json',json.dumps(payload,ensure_ascii=False),'--action-id',aid,ok=ok)
def events(repo,rid):return repo/'.cogito/runs'/rid/'events.jsonl'
def record(label,body):
 try:body();RESULTS.append({'case':label,'passed':True})
 except Exception as e:RESULTS.append({'case':label,'passed':False,'error':str(e),'traceback':traceback.format_exc()})
 (ROOT/'results.json').write_text(json.dumps(RESULTS,ensure_ascii=False,indent=2))

def check_error(p,path=None):
 assert p.returncode==2 and p.stdout=='' and 'Traceback' not in p.stderr,(p.returncode,p.stdout,p.stderr)
 err=json.loads(p.stderr);assert err['ok'] is False and err['error']
 if path:assert str(path) in err['error'],err

def encoding_and_recovery():
 repo,pkg=fixture('utf8-boundaries','maintenance');rid=pkg['run_id'];ev=events(repo,rid)
 valid=ROOT/'有效套件.json';pkg['stop_conditions'].append('保留完整中文');valid.write_text(json.dumps(pkg,ensure_ascii=False))
 bad8=ROOT/'invalid-utf8.json';bad8.write_bytes(b'{"reason":"\xff"}');bad16=ROOT/'utf16.json';bad16.write_bytes(json.dumps({'reason':'驗證錯誤'},ensure_ascii=False).encode('utf-16'))
 proof=[]
 for bad in [bad8,bad16]:
  before=ev.read_bytes();index=(repo/'.git/index').read_bytes()
  for cmd,flag in [('prepare-package','--package'),('approve','--package'),('agent-result','--input'),('amend','--amendment'),('verify','--evidence'),('post-verify','--evidence')]:
   p=cli(repo,cmd,'--run-id',rid,flag,bad,'--action-id',cmd+'-'+bad.stem,ok=False);check_error(p,bad)
   assert ev.read_bytes()==before and (repo/'.git/index').read_bytes()==index
  for opts in [('validate','--type','package','--input',str(bad)),('validate','--type','amendment','--input',str(valid),'--package',str(bad)),('validate','--type','amendment','--input',str(valid),'--package',str(valid),'--prior',str(bad))]:check_error(cli(repo,*opts,ok=False),bad)
  for args in [('--package',bad),('--package',valid,'--amendment',bad)]:
   p=run([sys.executable,SRC/'scripts/cogito_runner.py','run-check',*args,'--check-id','C-1','--worktree',repo,'--evidence-dir',ROOT/'must-not-create-evidence']);check_error(p,bad)
   assert not (ROOT/'must-not-create-evidence').exists()
  proof.append({'file':bad.name,'events_before_sha256':hashlib.sha256(before).hexdigest(),'events_after_sha256':hashlib.sha256(ev.read_bytes()).hexdigest(),'index_unchanged':index==(repo/'.git/index').read_bytes()})
 (ROOT/'utf8-rejection-proof.json').write_text(json.dumps(proof,indent=2))
 for cmd in ['prepare-package','approve']:cli(repo,cmd,'--run-id',rid,'--package',valid,'--action-id','valid-'+cmd)
 canonical=repo/f'docs/cogito/packages/{rid}.json';canonical.chmod(0o644);original=canonical.read_bytes();before=ev.read_bytes()
 for bad in [bad8,bad16]:
  canonical.write_bytes(bad.read_bytes());damaged=canonical.read_bytes();p=cli(repo,'status','--run-id',rid,ok=False);check_error(p,canonical);assert canonical.read_bytes()==damaged and ev.read_bytes()==before;canonical.write_bytes(original)
 canonical.chmod(0o444)
 cache=ev.with_name('state.json');expected=json.loads(cli(repo,'status','--run-id',rid).stdout)['data'];proof=[]
 for bad in [bad8,bad16]:
  cache.write_bytes(bad.read_bytes());p=cli(repo,'status','--run-id',rid);assert json.loads(p.stdout)['data']==expected;assert json.loads(cache.read_text())==expected and ev.read_bytes()==before
  proof.append({'damaged_cache':bad.name,'restored_from_events':True,'event_sha256':hashlib.sha256(before).hexdigest()})
 (ROOT/'cache-recovery-proof.json').write_text(json.dumps(proof,indent=2))
 cached=cache.read_bytes();proof=[]
 for bad in [bad8,bad16]:
  damaged=before+bad.read_bytes()+b'\n';ev.write_bytes(damaged);p=cli(repo,'status','--run-id',rid,ok=False);check_error(p)
  assert 'cannot read event log' in json.loads(p.stderr)['error'];assert ev.read_bytes()==damaged and cache.read_bytes()==cached
  (ROOT/(bad.stem+'-damaged-events.jsonl')).write_bytes(damaged)
  proof.append({'encoding':bad.name,'before_sha256':hashlib.sha256(damaged).hexdigest(),'after_sha256':hashlib.sha256(ev.read_bytes()).hexdigest(),'cache_unchanged':True})
  ev.write_bytes(before)
 (ROOT/'authoritative-rejection-proof.json').write_text(json.dumps(proof,indent=2))
record('All UTF8 CLI boundaries; frozen package rejection; authoritative log preserved; disposable cache recovered',encoding_and_recovery)
print(json.dumps(RESULTS,ensure_ascii=False,indent=2))
