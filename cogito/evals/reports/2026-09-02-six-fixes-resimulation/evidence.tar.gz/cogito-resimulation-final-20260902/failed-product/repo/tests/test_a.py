from pathlib import Path
import unittest

class ProductContentTests(unittest.TestCase):
    def test_content(self):
        self.assertEqual(Path('src/a.txt').read_text(), 'a0\n')
