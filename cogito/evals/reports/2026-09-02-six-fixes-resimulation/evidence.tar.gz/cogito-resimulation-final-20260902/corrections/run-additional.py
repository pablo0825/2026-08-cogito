import sys,json,time,subprocess
from pathlib import Path
sys.path.insert(0,'/Users/pablo/Documents/project/2026-08-cogito/cogito/tests')
from cogito_test_support import isolated_git_environment,init_repo,git,package
from cogito_contracts import package_hash
OUT=Path('/tmp/cogito-resimulation-final-20260902/corrections');GATE='/Users/pablo/Documents/project/2026-08-cogito/cogito/scripts/cogito_gate.py'
class Reject(Exception):pass
class CLI:
 def __init__(self,root,run):self.repo=root;self.run_id=run;self.run_dir=root/'.cogito/runs'/run;self.seq=0;self.log=root.parent/'cli-transcript.jsonl'
 def call(self,cmd,*opts):
  self.seq+=1;args=[sys.executable,'-B',GATE,'--repo',str(self.repo),cmd,'--run-id',self.run_id,*map(str,opts)]
  if cmd not in {'init','status','next','report'}:args+=['--action-id',f'action-{self.seq}']
  t=time.monotonic();p=subprocess.run(args,text=True,capture_output=True,timeout=30)
  with self.log.open('a') as f:f.write(json.dumps({'argv':args,'code':p.returncode,'elapsed_seconds':time.monotonic()-t,'stdout':p.stdout,'stderr':p.stderr})+'\n')
  if p.returncode:raise Reject(p.stderr)
  value=json.loads(p.stdout)['data']
  if cmd not in {'next','report'}:self.call('next')
  return value
 def payload(self,value):
  p=self.run_dir/'drafts'/f'input-{self.seq+1}.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value));return p
 def transition(self,event,payload):return self.call('transition','--event',event,'--payload-json',self.payload(payload))
 def events(self):return (self.run_dir/'events.jsonl').read_bytes()
 def check(self):
  before=set((self.run_dir/'evidence').glob('*.json'));self.call('run-check','--check-id','C-1','--worktree',self.repo);p,=set((self.run_dir/'evidence').glob('*.json'))-before;e=json.loads(p.read_text());assert e['passed'];return e
summaries=[]
with isolated_git_environment():
 for case in ['documentation','staged-good','staged-before','staged-after']:
  started=time.monotonic();directory=OUT/case;directory.mkdir();repo=directory/'repo';repo.mkdir();init_repo(repo);(repo/'.gitignore').write_text('.cogito/\ndocs/cogito/packages/\n');(repo/'note.txt').write_text('existing meaning\n\n');(repo/'unrelated.txt').write_text('preserve\n');git(repo,'add','.');git(repo,'commit','-qm','baseline');base=git(repo,'rev-parse','HEAD');run='DEV-final-'+case;kind='documentation' if case=='documentation' else 'maintenance';p=package(kind);p.update(run_id=run,baseline_commit=base,approved_paths=['note.txt'],execution_dag={'tasks':[{'id':'T-1','paths':['note.txt']}],'edges':[]},checks=[{'id':'C-1','required':True,'argv':[sys.executable,'-I','-c',"from pathlib import Path; assert Path('note.txt').read_text() == 'existing meaning\\n'"]}]);c=CLI(repo,run);c.call('init','--kind',kind);c.call('prepare-package','--package',c.payload(p));c.call('approve','--package',c.payload(p));c.call('start');c.call('task','--task-id','T-1','--status','leased','--agent-id','worker');c.call('task','--task-id','T-1','--status','running','--agent-id','worker');(repo/'note.txt').write_text('existing meaning\n');git(repo,'add','note.txt')
  if kind=='documentation':git(repo,'commit','-qm','整理既有文件空白')
  head=git(repo,'rev-parse','HEAD');assert head==base if kind=='maintenance' else head!=base
  result={'schema_version':'3.0','run_id':run,'task_id':'T-1','agent_id':'worker','role':'implementer','status':'complete','base_commit':base,'head_commit':head,'changed_paths':['note.txt'],'evidence':[],'risks':[],'requested_transition':'verifying'}
  if case=='staged-before':
   (repo/'unrelated.txt').write_text('outside\n');git(repo,'add','unrelated.txt');before=c.events();idx=(repo/'.git/index').read_bytes()
   try:c.call('agent-result','--input',c.payload(result));raise AssertionError('outside staged accepted')
   except Reject as e:error=str(e);assert 'changed_paths' in error or 'responsibility' in error
   assert before==c.events() and idx==(repo/'.git/index').read_bytes();state=c.call('status');summary={'case':case,'state':state['state'],'expected_rejection':True,'error':error,'events_and_index_unchanged':True,'elapsed_seconds':time.monotonic()-started};summaries.append(summary);(directory/'summary.json').write_text(json.dumps(summary,indent=2));continue
  c.call('agent-result','--input',c.payload(result));c.call('task','--task-id','T-1','--status','complete','--agent-id','worker');c.transition('implementation-complete',{});pre=c.check();c.call('verify','--evidence',pre['evidence_path']);reviews=[]
  if kind=='documentation':
   reviewer={**result,'agent_id':'reviewer','role':'reviewer','reviewed_implementer':'worker','changed_paths':[],'requested_transition':'review-approved'};c.call('agent-result','--input',c.payload(reviewer));c.transition('review-approved',{});reviews=[{'reviewer':'reviewer'}]
  else:c.transition('review-approved',{'review_exemption':True})
  c.call('integrate','--commit-id',head)
  if case=='staged-after':(repo/'unrelated.txt').write_text('outside after result\n');git(repo,'add','unrelated.txt')
  post=c.check();c.call('post-verify','--evidence',post['evidence_path']);graphp=repo/'docs/cogito/project-graph.json';graph=json.loads(graphp.read_text());graph['active_run_id']=None;graphp.write_text(json.dumps(graph));rp=repo/f'docs/cogito/results/{run}.json';rp.parent.mkdir(parents=True);state=c.call('status');rp.write_text(json.dumps({'schema_version':'3.0','run_id':run,'status':'accepted','package_hash':state['package_hash'],'effective_contract_hash':state['effective_contract_hash'],'integration_commits':[head],'slice_dispositions':{},'checks':[{'id':'C-1','status':'passed','evidence':post['evidence_path']}],'reviews':reviews,'amendments':[],'human_gate':{'required':False,'outcome':'not-required'},'remaining_risks':[]}));git(repo,'add','note.txt','docs/cogito/project-graph.json',str(rp));git(repo,'commit','-qm','完成結案');final=git(repo,'rev-parse','HEAD');count=int(git(repo,'rev-list','--count',f'{base}..{final}'));assert count==(2 if kind=='documentation' else 1);before=c.events();idx=(repo/'.git/index').read_bytes()
  if case=='staged-after':
   try:c.call('finalize','--result',str(rp.relative_to(repo)),'--final-commit',final);raise AssertionError('outside final accepted')
   except Reject as e:error=str(e);assert 'approved paths' in error
   assert before==c.events() and idx==(repo/'.git/index').read_bytes();state=c.call('status');assert state['state']=='finalizing';summary={'case':case,'state':state['state'],'expected_rejection':True,'error':error,'events_and_index_unchanged':True,'post_snapshot_contains_outside':git(repo,'show',post['worktree_binding']['content_tree']+':unrelated.txt')=='outside after result'}
  else:
   c.call('finalize','--result',str(rp.relative_to(repo)),'--final-commit',final);report=c.call('report');assert report['status']=='accepted';assert report['reviews']==reviews;(directory/'report.json').write_text(json.dumps(report,indent=2));summary={'case':case,'state':'accepted','expected_rejection':False,'reviews':reviews}
  events=[json.loads(x) for x in c.events().splitlines()];assert sum(x['type']=='integration-complete' for x in events)==1;summary.update(base=base,final=final,new_commit_count=count,integration_count=1,elapsed_seconds=time.monotonic()-started);summaries.append(summary);(directory/'summary.json').write_text(json.dumps(summary,indent=2))
(OUT/'additional-summary.json').write_text(json.dumps(summaries,indent=2));print('PASS',[(x['case'],x['state']) for x in summaries])
