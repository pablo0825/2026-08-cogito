import sys,json,subprocess,datetime
from pathlib import Path
sys.path.insert(0,'/Users/pablo/Documents/project/2026-08-cogito/cogito/tests')
from cogito_test_support import isolated_git_environment,init_repo,git,package
from test_maintenance_corrections import MaintenanceCli
from cogito_contracts import package_hash
OUT=Path('/tmp/cogito-resimulation-final-20260902/corrections');repo=OUT/'chain-repo';repo.mkdir()
class LoggedCli(MaintenanceCli):
 def call(self,command,*options):
  self.sequence+=1
  if command not in {'init','status','report','next'}:options=(*options,'--action-id',f'chain-{self.sequence}')
  started=__import__('time').monotonic()
  argv=[sys.executable,'-B','/Users/pablo/Documents/project/2026-08-cogito/cogito/scripts/cogito_gate.py','--repo',str(self.repo),command,'--run-id',self.run_id,*map(str,options)]
  p=subprocess.run(argv,text=True,capture_output=True,timeout=30)
  with (OUT/'cli-transcript.jsonl').open('a') as f:f.write(json.dumps({'argv':argv,'code':p.returncode,'elapsed_seconds':__import__('time').monotonic()-started,'stdout':p.stdout,'stderr':p.stderr})+'\n')
  if p.returncode:raise RuntimeError(p.stderr)
  if command not in {'next','report'}:self.call('next')
  return json.loads(p.stdout)['data']
with isolated_git_environment():
 init_repo(repo);(repo/'.gitignore').write_text('.cogito/\ndocs/cogito/packages/\n');(repo/'note.txt').write_text('before\n');git(repo,'add','.');git(repo,'commit','-qm','baseline');base=git(repo,'rev-parse','HEAD')
 run='DEV-resimulation-chain';draft=package('maintenance');draft.update(run_id=run,baseline_commit=base,approved_paths=['note.txt'],execution_dag={'tasks':[{'id':'T-1','paths':['note.txt']}],'edges':[]},checks=[{'id':'C-1','required':True,'argv':[sys.executable,'-I','-c',"from pathlib import Path; assert Path('note.txt').read_text().strip() == 'after'"]}])
 c=LoggedCli(repo,run);c.create('maintenance');c.prepare_package(draft);c.approve_package(draft);c.start_gate()
 def implement(task,content):
  c.update_task(task,'leased','worker');c.update_task(task,'running','worker');(repo/'note.txt').write_text(content)
  c.submit_agent_result({'schema_version':'3.0','run_id':run,'task_id':task,'agent_id':'worker','role':'implementer','status':'complete','base_commit':base,'head_commit':base,'changed_paths':['note.txt'],'evidence':[],'risks':[],'requested_transition':'verifying'});c.update_task(task,'complete','worker')
 def review(task,status,requested,risks=[]):
  c.submit_agent_result({'schema_version':'3.0','run_id':run,'task_id':task,'agent_id':'reviewer','role':'reviewer','status':status,'reviewed_implementer':'worker','base_commit':base,'head_commit':base,'changed_paths':[],'evidence':[],'risks':risks,'requested_transition':requested})
 outcomes=[]
 def check(name,expected):
  before=set((c.run_dir/'evidence').glob('*.json'));c.run_controlled_check('C-1',repo,name);p,=set((c.run_dir/'evidence').glob('*.json'))-before;e=json.loads(p.read_text());assert e['passed'] is expected,(name,e);outcomes.append({'name':name,'passed':e['passed'],'evidence':str(p)});return e
 def unchanged():assert git(repo,'rev-parse','HEAD')==base
 implement('T-1','wrong\n');c.transition('implementation-complete',{});check('pre-failed',False)
 c.add_amendment({'id':'TA-pre','reason':'修正內部文字錯誤','path_fixes':['note.txt']});c.enter_correction();(repo/'note.txt').write_text('after\n\n');c.complete_correction('TA-pre',base);unchanged();c.complete_verification([check('pre-fixed',True)])
 review('T-1','needs-fix','review-fix',['移除多餘空行']);c.call('review-fix-start');c.add_amendment({'id':'TA-review','reason':'移除多餘空行','added_tasks':[{'id':'T-2','slice_id':'mini-package','paths':['note.txt']}]});implement('T-2','after\n');c.call('review-fix-complete','--amendment-id','TA-review','--commit-id',base);unchanged();c.complete_verification([check('review-fixed',True)])
 review('T-1','complete','review-approved');review('T-2','complete','review-approved');c.transition('review-approved',{});c.complete_integration(base)
 (repo/'note.txt').write_text('post typo\n');check('post-failed',False);c.add_amendment({'id':'TA-post','reason':'修正整合檢查缺陷','path_fixes':['note.txt']});c.enter_correction();(repo/'note.txt').write_text('after\n');state=c.complete_correction('TA-post',base);assert state['state']=='post-integration-verification';unchanged();post=check('post-fixed',True);c.decide_post_verification([post])
 events=[json.loads(x) for x in c.events_path.read_text().splitlines()];completions=[x['payload'] for x in events if x['type'] in {'technical-correction-complete','review-fix-complete','post-integration-correction-complete'}];assert len(completions)==3;assert sum(x['type']=='integration-complete' for x in events)==1
 amendments=[]
 for x in completions:
  assert x['completion_mode']=='working-tree' and x['commit_id']==base
  assert git(repo,'cat-file','-t',x['content_tree'])=='tree'
  amendments.append({'id':x['amendment_id'],'base_commit':base,'content_tree':x['content_tree']})
 graphp=repo/'docs/cogito/project-graph.json';graph=json.loads(graphp.read_text());graph['active_run_id']=None;graphp.write_text(json.dumps(graph));resultrel=f'docs/cogito/results/{run}.json';rp=repo/resultrel;rp.parent.mkdir(parents=True)
 rp.write_text(json.dumps({'schema_version':'3.0','run_id':run,'status':'accepted','package_hash':package_hash(c.approved_package()),'effective_contract_hash':c.load()['effective_contract_hash'],'integration_commits':[base],'slice_dispositions':{},'checks':[{'id':'C-1','status':'passed','evidence':post['evidence_path']}],'reviews':[{'reviewer':'reviewer'}],'amendments':amendments,'human_gate':{'required':False,'outcome':'not-required'},'remaining_risks':[]}))
 git(repo,'add','note.txt','docs/cogito/project-graph.json',resultrel);git(repo,'commit','-qm','完成 Maintenance 模擬\n\n'+'\n'.join('Cogito-Amendment: '+x['id'] for x in amendments));final=git(repo,'rev-parse','HEAD');c.finalize(resultrel,'docs/cogito/project-graph.json',final);report=c.completion_report();assert report['status']=='accepted';assert git(repo,'rev-list','--count',f'{base}..{final}')=='1';assert report['amendments']==[{**x,'commit_id':final} for x in amendments];state=c.load();assert state['counters']['verification_corrections']==2 and state['counters']['review_fix_cycles']==1
 (OUT/'report.json').write_text(json.dumps(report,indent=2));(OUT/'chain-summary.json').write_text(json.dumps({'status':'accepted','base':base,'final':final,'new_commits':1,'integration_count':1,'counters':state['counters'],'checks':outcomes,'amendments':amendments,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2));print('PASS complete CLI chain',final)
