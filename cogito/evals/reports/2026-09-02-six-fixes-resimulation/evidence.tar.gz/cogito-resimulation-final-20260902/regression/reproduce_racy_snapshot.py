"""One minimal timing-controlled Git snapshot repro, without source changes."""
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path('/Users/pablo/Documents/project/2026-08-cogito')
OUT = Path('/tmp/cogito-resimulation-final-20260902/regression')
sys.path.insert(0, str(ROOT / 'cogito/tests'))
from cogito_test_support import git, init_repo, isolated_git_environment
from cogito_evidence_binding import working_tree_content_tree

repo = Path(tempfile.mkdtemp(prefix='racy-index-', dir=OUT))
with isolated_git_environment():
    init_repo(repo)
    # Keep baseline write, commit, and equal-size edit within the same second.
    time.sleep(1.05 - (time.time() % 1))
    note = repo / 'note.txt'
    note.write_text('before\n')
    git(repo, 'add', 'note.txt')
    git(repo, 'commit', '-qm', 'baseline')
    baseline_stat = note.stat()
    index_stat = (repo / '.git/index').stat()
    note.write_text('after\n\n')
    edited_stat = note.stat()
    # The original index remains racily clean; the copied index now gets a
    # later timestamp, and Git may wrongly trust the old equal-size stat entry.
    time.sleep(max(0, int(index_stat.st_mtime) + 1.10 - time.time()))
    diff = git(repo, 'diff', 'HEAD', '--', 'note.txt')
    snapshot = working_tree_content_tree(repo)
    captured = subprocess.check_output(['git', '-C', str(repo), 'show', f'{snapshot}:note.txt']).decode()
    report = {
        'repo': str(repo), 'same_second': int(baseline_stat.st_mtime) == int(edited_stat.st_mtime),
        'baseline_mtime_ns': baseline_stat.st_mtime_ns, 'edited_mtime_ns': edited_stat.st_mtime_ns,
        'index_mtime_ns': index_stat.st_mtime_ns, 'actual_content': note.read_text(),
        'original_index_diff': diff, 'snapshot_tree': snapshot, 'snapshot_content': captured,
        'reproduced_stale_snapshot': captured != note.read_text(),
    }
    (OUT / 'racy-snapshot-reproduction.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
