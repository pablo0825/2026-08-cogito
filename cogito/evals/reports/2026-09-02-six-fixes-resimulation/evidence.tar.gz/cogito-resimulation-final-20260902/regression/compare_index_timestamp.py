"""Change only the copied index timestamp in the retained minimal repro."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

OUT = Path('/tmp/cogito-resimulation-final-20260902/regression')
report = json.loads((OUT / 'racy-snapshot-reproduction.json').read_text())
repo = Path(report['repo'])
index = repo / '.git/index'
stat = index.stat()
sys.path.insert(0, '/Users/pablo/Documents/project/2026-08-cogito/cogito/tests')
from cogito_test_support import isolated_git_environment
with isolated_git_environment(), tempfile.TemporaryDirectory() as directory:
    copied = Path(directory) / 'index'
    shutil.copyfile(index, copied)
    os.utime(copied, ns=(stat.st_atime_ns, stat.st_mtime_ns))
    env = {**os.environ, 'GIT_INDEX_FILE': str(copied)}
    subprocess.run(['git', '-C', str(repo), 'add', '--all', '--', '.'], env=env, check=True)
    tree = subprocess.check_output(['git', '-C', str(repo), 'write-tree'], env=env).decode().strip()
    content = subprocess.check_output(['git', '-C', str(repo), 'show', f'{tree}:note.txt']).decode()
    report['preserved_index_timestamp_snapshot_content'] = content
    report['preserving_timestamp_corrects_snapshot'] = content == report['actual_content']
    (OUT / 'racy-snapshot-reproduction.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
