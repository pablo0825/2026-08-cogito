"""Analyze the already retained failure; does not run another check or edit sources."""
import copy
import hashlib
import itertools
import json
import subprocess
from pathlib import Path

root = Path('/tmp/cogito-resimulation-final-20260902/regression/review-fix-repeat/30')
repo = root / 'failed-repo-first-check'
evidence = json.loads((root / 'first-check.json').read_text())
post = {key: value for key, value in evidence['worktree_binding'].items() if key != 'snapshot_hash'}

def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

objects = git('cat-file', '--batch-all-objects', '--batch-check=%(objectname) %(objecttype)').decode().splitlines()
trees = [line.split()[0] for line in objects if line.endswith(' tree')]
hashes = [post['tracked_diff_sha256'], hashlib.sha256(b'').hexdigest()]
matches = []
for tree, diff_hash, untracked in itertools.product(trees, hashes, [post['untracked'], []]):
    candidate = {**post, 'content_tree': tree, 'tracked_diff_sha256': diff_hash, 'untracked': untracked}
    digest = hashlib.sha256(json.dumps(candidate, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    if digest == evidence['pre_worktree_snapshot_hash']:
        matches.append(candidate)
report = {'pre_binding_matches': matches, 'post_binding': post}
for match in matches:
    report['pre_to_post_content_diff'] = git('diff', '--binary', match['content_tree'], post['content_tree'], '--').decode()
    report['different_fields'] = [key for key in post if match[key] != post[key]]
(root / 'binding-analysis.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
