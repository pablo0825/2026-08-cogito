"""Repeat a positive-only maintenance test and save runner evidence before teardown."""
import io
import json
import shutil
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path('/Users/pablo/Documents/project/2026-08-cogito')
OUT = Path('/tmp/cogito-resimulation-final-20260902/regression/review-fix-repeat')
sys.path.insert(0, str(ROOT / 'cogito/tests'))
import test_maintenance_review_fix as test_module

OUT.mkdir(parents=True, exist_ok=True)
original = test_module.RunStore.run_controlled_check
summaries = []
start = time.monotonic()
for iteration in range(1, 31):
    if time.monotonic() - start >= 120:
        break
    target = OUT / f'{iteration:02d}'
    target.mkdir(exist_ok=True)
    evidence_records = []

    def capture(store, check_id, worktree, action_id):
        before = set((store.run_dir / 'evidence').glob('*.json'))
        try:
            return original(store, check_id, worktree, action_id)
        finally:
            for path in set((store.run_dir / 'evidence').glob('*.json')) - before:
                evidence = json.loads(path.read_text())
                shutil.copy2(path, target / f'{action_id}.json')
                evidence_records.append({'action': action_id, 'passed': evidence['passed'],
                                         'exit_code': evidence['exit_code'],
                                         'changed': evidence['worktree_changed_during_check']})
                if not evidence['passed']:
                    shutil.copytree(store.root, target / f'failed-repo-{action_id}', dirs_exist_ok=True)

    stream = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromName(
        'MaintenanceReviewFixTests.test_review_fix_records_snapshot_and_reverifies_added_task',
        test_module,
    )
    with patch.object(test_module.RunStore, 'run_controlled_check', capture):
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    (target / 'unittest.log').write_text(stream.getvalue())
    summary = {'iteration': iteration, 'passed': result.wasSuccessful(),
               'tests_run': result.testsRun, 'evidence': evidence_records}
    summaries.append(summary)
    print(json.dumps(summary), flush=True)

report = {'iterations': len(summaries), 'elapsed_seconds': round(time.monotonic() - start, 3),
          'failed_iterations': [item['iteration'] for item in summaries if not item['passed']],
          'records': summaries}
(OUT / 'summary.json').write_text(json.dumps(report, indent=2))
print(json.dumps({key: value for key, value in report.items() if key != 'records'}), flush=True)
