from pathlib import Path
import unittest

class ProductContentTests(unittest.TestCase):
    def test_content(self):
        self.assertEqual(Path('src/b.txt').read_text(), 'b1\n')
