value = 3
print(value)
