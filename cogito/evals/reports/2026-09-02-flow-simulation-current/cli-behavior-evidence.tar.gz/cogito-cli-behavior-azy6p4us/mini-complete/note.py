renamed_value = 3
print(renamed_value)
